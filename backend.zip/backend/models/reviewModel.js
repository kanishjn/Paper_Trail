const pool = require("../db");

exports.addReview = async(userId, productId, rating, comment) => {
    const result = await pool.query('INSERT INTO reviews (user_Id, product_Id, rating, comment) VALUES ($1,$2,$3,$4) RETURNING *',[userId, productId, rating, comment]);
    return result.rows[0]; //recently inserted row
};

exports.getReviewsByProductId = async(productId)=>{
    const result = await pool.query("SELECT r.*,u.username FROM reviews r JOIN users u ON r.user_id = u.id WHERE product_id = $1 ORDER BY created_at DESC",[productId]);
    return result.rows;
};

exports.getAverageRating = async(productId) => {
    const result = await pool.query("SELECT AVG(rating::numeric(2,1)) AS avg_rating FROM reviews WHERE product_id = $1", [productId]);
    return result.rows[0].avg_rating || 0;
};