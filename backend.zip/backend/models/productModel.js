//model acts as a bridge between the controller and the database
//it stores all logic related to the database

const pool = require('../db');

exports.createProduct = async ({title, description, price, seller_Id, genre, category, subcategory}) => {
    const result = await pool.query("INSERT INTO products(title, description, price, seller_Id, genre, category, subcategory) VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *", 
        [title, description, price, seller_Id, genre, category, subcategory]);

        return result.rows[0];
}

exports.getAllProducts = async() =>{
    const result = await pool.query("SELECT * FROM products ORDER BY created_at DESC");
    return result.rows;
}

exports.getProductById = async(id) => {
    const result = await pool.query("SELECT * FROM products WHERE id = $1", [id]);
    return result.rows[0];
}

exports.getProductsByGenre = async (genre) => {
    const result = await pool.query(
      'SELECT * FROM products WHERE LOWER(genre) = LOWER($1)',
      [genre]
    );
    return result.rows;
  };
  
  

exports.getUniversityProductsBySubcategory = async (subcategory) => {
    console.log('Running query with:', subcategory);
    const category = 'University'; // Assuming you want to filter by category 'University'
    const result = await pool.query(
        'SELECT * FROM products WHERE LOWER(category) = LOWER($1) AND LOWER(subcategory) = LOWER($2)',
        [category, subcategory]
      );
      
  return result.rows;
};

exports.saveImage = async (productId, imagePath) => {
  const result = await pool.query(
    'UPDATE products SET image = $1 WHERE id = $2',
    [imagePath, productId]
  );
  return result;
};

exports.searchProductsByName = async (query) => {
  const result = await pool.query(
      'SELECT * FROM products WHERE title ILIKE $1',
      [`%${query}%`] //ILIKE is a PostgreSQL operator that performs case-insensitive pattern matching (unlike LIKE, which is case-sensitive)
  );
  return result.rows;
};