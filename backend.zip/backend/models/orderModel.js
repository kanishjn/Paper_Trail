const db = require('../db');

exports.createOrder = async (buyerId, totalPrice, address) => {
  const result = await db.query(
    `INSERT INTO orders (buyer_id, purchase_date, address,status)
     VALUES ($1, CURRENT_TIMESTAMP,$2, 'pending') RETURNING id`,
    [buyerId,address]
  );
  return result.rows[0].id;
};

exports.addOrderItem = async (orderId, productId, quantity, price, sellerId) => {
  await db.query(
    `INSERT INTO order_items (order_id, product_id, quantity, price, seller_id)
     VALUES ($1, $2, $3, $4, $5)`,
    [orderId, productId, quantity, price, sellerId]
  );
};

exports.getUserOrderHistory = async (userId) => {
  const query = `
    SELECT 
      o.id AS order_id,
      o.purchase_date,
      o.status,
      p.id AS product_id,
      p.title AS product_name,
      oi.quantity,
      oi.price
    FROM orders o
    JOIN order_items oi ON o.id = oi.order_id
    JOIN products p ON p.id = oi.product_id
    WHERE o.buyer_id = $1
    ORDER BY o.purchase_date DESC;
  `;
  
  const result = await db.query(query, [userId]);
  return result.rows; 
};
