const pool = require('../db'); // Import the database connection pool

exports.addToCart = async(userId, productId, quantity=1) => {
        const result = await pool.query('INSERT INTO cart(user_id,product_id,quantity) VALUES($1,$2,$3) RETURNING *', [userId, productId, quantity]);
        return result.rows[0];
};

exports.getCartByUser  = async(userId) =>{
        const result = await pool.query(`SELECT c.id AS cart_item_id, p.*, c.quantity FROM cart c
            JOIN products p ON c.product_id = p.id
            WHERE c.user_id = $1`, [userId]);
        return result.rows;
};

exports.removeFromCart = async(cartItemId) => {
    await pool.query(`DELETE FROM cart WHERE id = $1`, [cartItemId]);
};