const pool = require('./db');
const express = require('express');
const app = express();//creates an instance of my express js application
require('dotenv').config(); // Loads environment variables from a .env file into process.env

app.use(express.json()); //is used to parse incoming JSON requests in an Express.js application(makes them available in req.body).

pool.query('SELECT NOW()', (err, res) => {
  if (err) {
    console.error('DB connection failed:', err);
  } else {
    console.log('DB connected at:', res.rows[0].now);
  }
});
console.log("Connecting with DB credentials:", {
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    host: process.env.DB_HOST,
    port: process.env.DB_PORT,
    database: process.env.DB_DATABASE
  });

app.use('/api/users', require('./routes/userRoutes')); 
app.use('/api/products', require("./routes/productRoutes"));
app.use('/api/cart', require("./routes/cartRoutes")); //This mounts the userRoutes.js router at the /api/users path
app.use('/api/orders', require("./routes/orderRoutes")); 
app.use('/api/reviews', require("./routes/reviewRoutes"));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});