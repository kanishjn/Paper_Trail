//middleware folder for Multer config
const multer = require('multer'); //Multer is a middleware to handle file uploads in Express.
// It configures how and where uploaded files should be stored on the server
const path = require('path'); //A built-in Node.js module used for working with file and directory paths.

const storage = multer.diskStorage({//create a storage for multer using .diskStorage method which takes an object with two properties: destination and filename.
  destination: function (req, file, cb) {
    cb(null, 'uploads/'); //destination tells multer where to store the uploaded files. In this case, it's the 'uploads/' directory.
  },
  filename: function (req, file, cb) {//tells us how to filename will be determined
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({ storage: storage });//This creates an instance of Multer with the configured storage settings (storage).

module.exports = upload;