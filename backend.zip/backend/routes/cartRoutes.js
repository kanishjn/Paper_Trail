const express = require('express');
const router = express.Router();
const cartController = require('../controllers/cartController');
const authenticate  = require('../middleware/authMiddleware'); // Middleware to authenticate user

router.post('/add', authenticate, cartController.addToCart); // Add a new product (protected route)
router.get('/', authenticate, cartController.getCartByUser); // Get all products  
router.delete('/:cartItemId', authenticate, cartController.removeFromCart); // Remove a product (protected route)

module.exports = router;