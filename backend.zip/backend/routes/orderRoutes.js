const express = require('express');
const router = express.Router();
const orderController = require('../controllers/orderController');
const authenticate = require('../middleware/authMiddleware'); 

router.post('/buy', authenticate, orderController.buyProduct);
router.get('/user/:userId',orderController.getUserOrderHistory);

module.exports = router;
