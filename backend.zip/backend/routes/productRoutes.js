const express = require('express');
const router = express.Router();
const productController = require('../controllers/productController');
const upload = require('../middleware/upload'); // Import the upload middleware

router.post('/', productController.createProduct);      
router.get('/', productController.getAllProducts); 
router.get('/search', productController.searchProducts);//Because Express matches routes top to bottom, and it thinks "search" is an :id unless told otherwise.
router.get('/:id', productController.getProductById);
router.get('/genre/:genre', productController.getProductsByGenre); // New route for getting products by genre
router.get('/:category/:subcategory', productController.getUniversityProductsBySubcategory); // New route for getting products by category
router.post('/:productId/upload-image', upload.single('image'), productController.uploadImage);
//upload.single('image') is a middleware function that processes a single file upload. The name 'image' should match the name of the file input in your form.

module.exports = router;