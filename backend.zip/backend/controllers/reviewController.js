const reviewModel = require("../models/reviewModel");

exports.addReview = async (req, res) => {
    try {
      const { userId, productId, rating, comment } = req.body;
      const review = await reviewModel.addReview(userId, productId, rating, comment);
      res.status(201).json(review);
    } catch (err) {
      console.error('Add Review Error:', err);
      res.status(500).json({ error: 'Error adding review' });
    }
  };

  
exports.getReviews = async (req, res) => {
    try {
      const { productId } = req.params;
      const reviews = await reviewModel.getReviewsByProductId(productId);
      const avgRating = await reviewModel.getAverageRating(productId);
      res.status(200).json({ reviews, avgRating });
    } catch (err) {
      console.error('Get Reviews Error:', err);
      res.status(500).json({ error: 'Error fetching reviews' });
    }
  };