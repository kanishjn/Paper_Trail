const orderModel = require('../models/orderModel');
const productModel = require('../models/productModel');

exports.buyProduct = async (req, res) => {
  try {
    const { userId, productId, quantity, address} = req.body;

    const product = await productModel.getProductById(productId);
    if (!product) {
      return res.status(404).json({ error: 'Product not found' });
    }

    const totalPrice = product.price * quantity;

    const orderId = await orderModel.createOrder(userId, totalPrice,address);
    await orderModel.addOrderItem(orderId, productId, quantity, product.price, product.seller_id);

    res.status(201).json({ message: 'Order placed successfully', orderId });
  } catch (err) {
    console.error('Buy Product Error:', err);
    res.status(500).json({ message: 'Internal server error' });
  }
};

exports.getUserOrderHistory = async (req, res) => {
  try {
    const userId = parseInt(req.params.userId);
    const orderHistory = await orderModel.getUserOrderHistory(userId);

    // Group by order_id
    const groupedOrders = {};
    for (const row of orderHistory) {//You're looping through each row in the result — each row = one product in an order.
      const { order_id, purchase_date, status, product_id, product_name, quantity, price } = row;

      if (!groupedOrders[order_id]) {//If this is the first time we're seeing this order_id...
        groupedOrders[order_id] = {//we create a new object for that order, with an empty products array.
          orderId: order_id,
          purchaseDate: purchase_date,
          status,
          products: []
        };
      }

      groupedOrders[order_id].products.push({//We add the current product to the products array inside that order.
        productId: product_id,
        name: product_name,
        quantity,
        price
      });
    }

    res.status(200).json(Object.values(groupedOrders));
  } catch (err) {
    console.error('Get Order History Error:', err);
    res.status(500).json({ error: 'Error fetching order history' });
  }
};

