const cartModel = require('../models/cartModel');

exports.addToCart = async (req, res) => {
    try {
      const { userId, productId, quantity } = req.body;
  
      if (!userId || !productId || !quantity) {
        return res.status(400).json({ message: 'Missing required fields' });
      }
  
      const result = await cartModel.addToCart(userId, productId, quantity);
      res.status(201).json({ message: 'Item added to cart', cartItem: result });
    } catch (error) {
      console.error('Add to cart error:', error);
      res.status(500).json({ message: 'Server error' });
    }
  };
  
exports.getCartByUser = async(req, res) =>{
    const userId = req.user.id; //Comes from the authenticated user using middleware (like JWT). you can use req.params.userId
    try{
        const cartItems = await cartModel.getCartByUser(userId);
        res.status(200).json({cartItems});
    }catch(err){
        res.status(500).json({ error: 'Failed to fetch cart items' });
    }
}

exports.removeFromCart = async(req, res) =>{
    const cartItemId = req.params.cartItemId; //comes from the URL (like /cart/:cartItemId)
    try{
        await cartModel.removeFromCart(cartItemId);
        res.status(200).json({message: 'Product removed from cart'});
    }catch(err){
        res.status(500).json({ error: 'Failed to remove from cart' });
    }
}