const productModel = require('../models/productModel');
const pool = require('../db'); // Import the database connection

exports.createProduct = async (req, res) => {
    try{const {title, description, price, seller_id, genre, category, subcategory} = req.body;
    const products = await productModel.createProduct({title, description, price, seller_id,genre, category, subcategory});
    res.status(201).json({products});}
    catch(err){
        console.log(err);
        res.status(500).json({error: 'Product creation failed'});
    }
};

exports.getAllProducts = async (req, res) => {
    try {
      const products = await productModel.getAllProducts();
      res.json({ products });
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: 'Could not retrieve products' });
    }
  };
  
  exports.getProductById = async (req, res) => {
    try {
      const product = await productModel.getProductById(req.params.id);
      if (!product) return res.status(404).json({ error: 'Product not found' });
      res.json({ product });
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: 'Error fetching product' });
    }
  };

  exports.getProductsByGenre = async (req, res) => {
    const { genre } = req.params;
    try {
      const result = await productModel.getProductsByGenre(genre);
      res.json(result);
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: 'Failed to fetch products by genre' });
    }
  };
  
  exports.getUniversityProductsBySubcategory = async (req, res) => {
    const subcategory  = req.params.subcategory; //We are getting a url parameter(subcategory) from an incoming http request
    try {
      const products = await productModel.getUniversityProductsBySubcategory(subcategory);
      res.json(products);
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: 'Something went wrong' });
    }
  };

  exports.uploadImage = async (req, res) => {
    const productId = req.params.productId;
    const imagePath = req.file.path; //That comes from Multer. When you use upload.single('image'), Multer:Parses the form data, Finds the image field, Saves the image to the disk (like in /uploads/ folder) and Adds a file object to the req.
    try {
      await productModel.saveImage(productId, imagePath);
      res.status(200).json({ message: 'Image uploaded successfully', path: imagePath });
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: 'Failed to upload image' });
    }
  };

  exports.searchProducts = async(req, res) =>{
    try{
      const query = req.query.query; //Extracting the query parameter from the request URL

      if(!query){
        return res.status(400).json({error:"Query required"});
      }
      const result = await productModel.searchProductsByName(query);
      res.status(200).json(result); //Sending the result back to the client
    } catch(err){
      console.log(err);
      res.status(500).json({error: 'Something went wrong'});
    }  
  };
  